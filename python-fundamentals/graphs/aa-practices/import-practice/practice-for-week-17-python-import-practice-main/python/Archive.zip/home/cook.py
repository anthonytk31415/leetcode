def washVegetables():
    print("Washing vegetables...")
    print("Done")

def chopMeat():
    print("Chopping meat...")
    print("Done")
