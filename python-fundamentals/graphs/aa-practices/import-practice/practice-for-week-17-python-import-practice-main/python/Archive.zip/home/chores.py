def doDishes():
    print("Doing dishes...")
    print("Done")

def takeOutTrash():
    print("Taking out trash...")
    print("Done")

def sweepFloors():
    print("Sweeping the floors...")
    print("Done")
