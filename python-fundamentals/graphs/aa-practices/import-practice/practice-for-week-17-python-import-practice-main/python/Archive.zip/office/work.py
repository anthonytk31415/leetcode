def code():
    print("Coding...")
    print("Done... for now.")

def attendMeeting():
    print("Attending meeting...")
    print("Done")

def updateSchedule():
    print("Updating schedule...")
    print("Done")
