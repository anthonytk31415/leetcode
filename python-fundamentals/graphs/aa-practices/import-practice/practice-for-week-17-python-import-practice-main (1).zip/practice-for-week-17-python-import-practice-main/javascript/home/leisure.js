const playGames = () => {
    console.log("Playing games...");
    console.log("Just a little more...");
    console.log("Done");
}

const petDog = () => {
    console.log("Petting doggo...");
    console.log("Done");
}

const readBook = () => {
    console.log("Reading book...");
    console.log("Done");
}

const takeNap = () => {
    console.log("Taking nap...");
    console.log("Uh oh, it's 5 hours later.");
}

module.exports = {
    playGames,
    petDog,
    readBook,
    takeNap
}