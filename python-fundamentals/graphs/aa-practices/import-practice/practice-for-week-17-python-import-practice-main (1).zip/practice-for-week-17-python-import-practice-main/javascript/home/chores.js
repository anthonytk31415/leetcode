const doDishes = () => {
    console.log("Doing dishes...");
    console.log("Done");
}

const takeOutTrash = () => {
    console.log("Taking out trash...");
    console.log("Done");
}

const sweepFloors = () => {
    console.log("Sweeping the floors...");
    console.log("Done");
}

module.exports = {
    doDishes,
    takeOutTrash,
    sweepFloors
}