const washVegetables = () => {
    console.log("Washing vegetables...");
    console.log("Done");
}

const chopMeat = () => {
    console.log("Chopping meat...");
    console.log("Done");
}

module.exports = {
    washVegetables,
    chopMeat
}