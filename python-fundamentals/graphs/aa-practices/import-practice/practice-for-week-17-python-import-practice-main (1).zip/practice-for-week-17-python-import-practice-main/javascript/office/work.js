const code = () => {
    console.log("Coding...");
    console.log("Done... for now.");
}

const attendMeeting = () => {
    console.log("Attending meeting...");
    console.log("Done");
}

const updateSchedule = () => {
    console.log("Updating schedule...");
    console.log("Done");
}

module.exports = {
    code,
    attendMeeting,
    updateSchedule
}