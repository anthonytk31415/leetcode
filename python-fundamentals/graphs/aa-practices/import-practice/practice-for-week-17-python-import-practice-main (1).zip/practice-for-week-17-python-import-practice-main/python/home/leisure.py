def playGames():
    print("Playing games...")
    print("Just a little more...")
    print("Done")

def petDog():
    print("Petting doggo...")
    print("Done")

def readBook():
    print("Reading book...")
    print("Done")

def takeNap():
    print("Taking nap...")
    print("Uh oh, it's 5 hours later.")
