class LinkedList:
  def __init__(self):
    self._head = None
    self._tail = None
    self._length = None

blah = LinkedList()
print(blah)